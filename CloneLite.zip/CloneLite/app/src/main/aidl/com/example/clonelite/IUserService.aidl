package com.example.clonelite;

interface IUserService {
    void destroy() = 16777114;
    String exec(String command) = 1;
}
