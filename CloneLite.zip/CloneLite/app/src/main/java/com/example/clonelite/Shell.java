package com.example.clonelite;

import android.os.Handler;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** Runs shell commands through the Shizuku user service on background threads. */
final class Shell {

    private final Handler ui;
    private final Consumer<String> logSink;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private volatile IUserService svc;

    Shell(Handler ui, Consumer<String> logSink) {
        this.ui = ui;
        this.logSink = logSink;
    }

    void setService(IUserService s) {
        svc = s;
    }

    boolean ready() {
        return svc != null;
    }

    void log(String s) {
        ui.post(() -> logSink.accept(s));
    }

    /** cb (may be null) is called on the UI thread with the command output. */
    void run(String cmd, boolean quiet, Consumer<String> cb) {
        try {
            pool.execute(() -> {
                String out;
                try {
                    IUserService s = svc;
                    out = (s == null) ? "ERROR: Shizuku not connected" : s.exec(cmd);
                } catch (Exception e) {
                    out = "ERROR: " + e;
                }
                final String res = out;
                ui.post(() -> {
                    if (!quiet) {
                        logSink.accept("$ " + cmd + "\n" + res);
                    }
                    if (cb != null) {
                        cb.accept(res);
                    }
                });
            });
        } catch (Exception ignored) {
        }
    }

    void shutdown() {
        pool.shutdown();
    }
}
