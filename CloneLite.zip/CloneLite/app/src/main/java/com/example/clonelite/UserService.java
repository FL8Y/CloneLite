package com.example.clonelite;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Runs inside the Shizuku server process with shell (adb) rights. */
public class UserService extends IUserService.Stub {

    public UserService() {
    }

    @Override
    public void destroy() {
        System.exit(0);
    }

    @Override
    public String exec(String command) {
        try {
            Process p = new ProcessBuilder("sh", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            try (InputStream in = p.getInputStream()) {
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }
            p.waitFor();
            return out.toString("UTF-8").trim();
        } catch (Exception e) {
            return "ERROR: " + e;
        }
    }
}
