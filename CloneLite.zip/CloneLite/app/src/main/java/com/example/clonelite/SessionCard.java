package com.example.clonelite;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.SurfaceTexture;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** One running clone: a virtual screen with a live preview, touch control and auto recovery. */
final class SessionCard extends LinearLayout {

    static final int W = 540;
    static final int H = 960;
    static final int DPI = 240;
    private static final String ROBLOX = "com.roblox.client";

    private final Context ctx;
    private final Shell shell;
    private final SharedPreferences prefs;
    final String pkg;
    private final String label;
    private final int user;

    private final TextureView tv;
    private final TextView stateView;
    private final EditText targetEdit;
    private final CheckBox recoverBox;

    private VirtualDisplay vd;
    private Surface surface;
    private int displayId = -1;
    private boolean running = false;
    private long lastLaunch = 0;
    private int restarts = 0;
    private float downX;
    private float downY;
    private long downT;

    SessionCard(Context ctx, Shell shell, SharedPreferences prefs,
                String pkg, String label, int user) {
        super(ctx);
        this.ctx = ctx;
        this.shell = shell;
        this.prefs = prefs;
        this.pkg = pkg;
        this.label = label;
        this.user = user;

        setOrientation(VERTICAL);
        int p = dp(10);
        setPadding(p, p, p, p);
        setBackgroundColor(0x14000000);
        LayoutParams cardLp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, 0, 0, dp(10));
        setLayoutParams(cardLp);

        TextView title = new TextView(ctx);
        title.setText(label);
        title.setTextSize(16);
        addView(title);

        stateView = new TextView(ctx);
        stateView.setText("Stopped");
        stateView.setTextSize(12);
        addView(stateView);

        tv = new TextureView(ctx);
        addView(tv, new LayoutParams(dp(180), dp(320)));
        setupTexture();
        setupTouch();

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(HORIZONTAL);
        row.addView(smallBtn("Start", v -> start()), weight());
        row.addView(smallBtn("Stop", v -> stop()), weight());
        row.addView(smallBtn("Back", v -> key(4)), weight());
        row.addView(smallBtn("Type", v -> promptText()), weight());
        addView(row, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        targetEdit = new EditText(ctx);
        targetEdit.setHint("Roblox place ID or game link (optional)");
        targetEdit.setSingleLine(true);
        targetEdit.setTextSize(13);
        targetEdit.setText(prefs.getString("t_" + pkg, ""));
        addView(targetEdit, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        recoverBox = new CheckBox(ctx);
        recoverBox.setText("Auto restart / rejoin");
        recoverBox.setChecked(prefs.getBoolean("r_" + pkg, false));
        addView(recoverBox);
    }

    boolean isRunning() {
        return running;
    }

    // ---------- UI helpers ----------

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private LayoutParams weight() {
        return new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
    }

    private Button smallBtn(String text, View.OnClickListener l) {
        Button b = new Button(ctx);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private void setState(String s) {
        stateView.setText(s);
    }

    // ---------- Preview surface ----------

    private void setupTexture() {
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                st.setDefaultBufferSize(W, H);
                surface = new Surface(st);
                if (vd != null) {
                    vd.setSurface(surface);
                }
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                if (vd != null) {
                    vd.setSurface(null);
                }
                if (surface != null) {
                    surface.release();
                    surface = null;
                }
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture st) {
            }
        });
    }

    // ---------- Touch control (sent to the virtual screen with the input command) ----------

    private void setupTouch() {
        tv.setOnTouchListener((v, e) -> {
            int w = Math.max(1, v.getWidth());
            int h = Math.max(1, v.getHeight());
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                downX = e.getX();
                downY = e.getY();
                downT = e.getEventTime();
                return true;
            }
            if (action == MotionEvent.ACTION_UP) {
                if (!running || displayId < 0) {
                    return true;
                }
                int x1 = (int) (downX * W / w);
                int y1 = (int) (downY * H / h);
                int x2 = (int) (e.getX() * W / w);
                int y2 = (int) (e.getY() * H / h);
                long dur = Math.max(100, e.getEventTime() - downT);
                String cmd;
                if (Math.abs(x2 - x1) < 20 && Math.abs(y2 - y1) < 20) {
                    cmd = "input -d " + displayId + " tap " + x1 + " " + y1;
                } else {
                    cmd = "input -d " + displayId + " swipe " + x1 + " " + y1
                            + " " + x2 + " " + y2 + " " + dur;
                }
                shell.run(cmd, true, null);
                return true;
            }
            return true;
        });
    }

    private void key(int code) {
        if (running && displayId >= 0) {
            shell.run("input -d " + displayId + " keyevent " + code, true, null);
        }
    }

    private void promptText() {
        if (!running || displayId < 0) {
            return;
        }
        final EditText et = new EditText(ctx);
        new AlertDialog.Builder(ctx)
                .setTitle("Type into " + label)
                .setView(et)
                .setPositiveButton("Send", (d, w) -> {
                    String t = et.getText().toString()
                            .replaceAll("[^A-Za-z0-9 ._@+-]", "")
                            .replace(" ", "%s");
                    if (!t.isEmpty()) {
                        shell.run("input -d " + displayId + " text " + t, true, null);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- Start / stop / recovery ----------

    void start() {
        if (running) {
            return;
        }
        prefs.edit()
                .putString("t_" + pkg, targetEdit.getText().toString().trim())
                .putBoolean("r_" + pkg, recoverBox.isChecked())
                .apply();
        DisplayManager dm = (DisplayManager) ctx.getSystemService(Context.DISPLAY_SERVICE);
        try {
            vd = dm.createVirtualDisplay("clone-" + pkg, W, H, DPI, surface,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC
                            | DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY);
        } catch (Exception e) {
            setState("Could not create screen: " + e.getMessage());
            return;
        }
        if (vd == null) {
            setState("Could not create screen");
            return;
        }
        displayId = vd.getDisplay().getDisplayId();
        running = true;
        setState("Starting on screen " + displayId + "...");
        launch();
    }

    void stop() {
        running = false;
        shell.run("am force-stop --user " + user + " " + pkg, true, null);
        if (vd != null) {
            vd.release();
            vd = null;
        }
        displayId = -1;
        setState("Stopped");
    }

    /** Release the screen when the app closes. */
    void release() {
        if (vd != null) {
            vd.release();
            vd = null;
        }
        running = false;
    }

    private void launch() {
        lastLaunch = System.currentTimeMillis();
        String uri = pkg.equals(ROBLOX) ? robloxUri(targetEdit.getText().toString().trim()) : null;
        String base = "am start-user " + user + " >/dev/null 2>&1; ";
        String cmd;
        if (uri != null) {
            cmd = base + "am start --user " + user + " --display " + displayId
                    + " -a android.intent.action.VIEW -d '" + uri + "' -p " + pkg;
        } else {
            cmd = base + "C=$(cmd package resolve-activity --brief --user " + user
                    + " -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p "
                    + pkg + " | tail -n 1); "
                    + "am start --user " + user + " --display " + displayId + " -n \"$C\"";
        }
        shell.run(cmd, true, r -> setState(restarts == 0
                ? "Running on screen " + displayId
                : "Running on screen " + displayId + " (restarts: " + restarts + ")"));
    }

    /** Called every few seconds by the activity. */
    void checkAlive() {
        if (!running || !recoverBox.isChecked()) {
            return;
        }
        if (System.currentTimeMillis() - lastLaunch < 45000) {
            return;
        }
        String cmd = "ps -A -o USER,NAME | grep '^u" + user + "_' | grep -c ' " + pkg + "$'";
        shell.run(cmd, true, r -> {
            if (running && r.trim().equals("0")) {
                restarts++;
                shell.log("[" + label + "] not running, restarting (#" + restarts + ")");
                launch();
            }
        });
    }

    // ---------- Roblox link handling ----------

    /** Turns a place ID or Roblox link into a roblox:// link, or null if unusable. */
    static String robloxUri(String t) {
        if (t == null || t.isEmpty()) {
            return null;
        }
        if (t.matches("\\d+")) {
            return "roblox://placeId=" + t;
        }
        if (t.startsWith("roblox://")) {
            return t.matches("[A-Za-z0-9:/?&=._%-]+") ? t : null;
        }
        Matcher share = Pattern.compile("share\\?code=([A-Za-z0-9]+)&type=Server").matcher(t);
        if (share.find()) {
            return "roblox://navigation/share_links?code=" + share.group(1) + "&type=Server";
        }
        Matcher place = Pattern.compile("/games/(\\d+)").matcher(t);
        Matcher code = Pattern.compile("privateServerLinkCode=([A-Za-z0-9]+)").matcher(t);
        if (place.find()) {
            String uri = "roblox://placeId=" + place.group(1);
            if (code.find()) {
                uri += "&linkCode=" + code.group(1);
            }
            return uri;
        }
        return null;
    }
}
