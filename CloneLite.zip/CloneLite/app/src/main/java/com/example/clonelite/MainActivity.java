package com.example.clonelite;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ_SHIZUKU = 1001;
    private static final String SPACE_NAME = "CloneSpace";
    private static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<String> labels = new ArrayList<>();
    private final List<String> pkgs = new ArrayList<>();

    private TextView statusView;
    private TextView logView;
    private ScrollView logScroll;
    private Button createBtn;
    private Button removeBtn;
    private ListView listView;

    private Shizuku.UserServiceArgs serviceArgs;
    private IUserService svc;
    private boolean binding = false;
    private boolean permAsked = false;
    private int spaceId = -1;

    private final Shizuku.OnBinderReceivedListener binderReceived =
            () -> ui.post(this::refresh);

    private final Shizuku.OnBinderDeadListener binderDead = () -> {
        svc = null;
        binding = false;
        ui.post(this::refresh);
    };

    private final Shizuku.OnRequestPermissionResultListener permResult =
            (code, result) -> {
                permAsked = false;
                ui.post(this::refresh);
            };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = IUserService.Stub.asInterface(binder);
            binding = false;
            ui.post(() -> {
                refresh();
                findSpace();
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
            binding = false;
            ui.post(() -> refresh());
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadApps();
        buildUi();

        serviceArgs = new Shizuku.UserServiceArgs(
                new ComponentName(getPackageName(), UserService.class.getName()))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(false)
                .version(1);

        Shizuku.addBinderReceivedListenerSticky(binderReceived);
        Shizuku.addBinderDeadListener(binderDead);
        Shizuku.addRequestPermissionResultListener(permResult);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (serviceArgs != null) {
            refresh();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeBinderReceivedListener(binderReceived);
        Shizuku.removeBinderDeadListener(binderDead);
        Shizuku.removeRequestPermissionResultListener(permResult);
        try {
            Shizuku.unbindUserService(serviceArgs, conn, false);
        } catch (Throwable ignored) {
        }
        io.shutdown();
    }

    // ---------- UI ----------

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(12);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Clone Lite");
        title.setTextSize(22);
        root.addView(title, new LinearLayout.LayoutParams(MATCH, WRAP));

        statusView = new TextView(this);
        statusView.setPadding(0, dp(6), 0, dp(6));
        root.addView(statusView, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        createBtn = makeButton("Create space", v -> createSpace());
        removeBtn = makeButton("Remove space", v -> confirmRemove());
        row.addView(createBtn, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(removeBtn, new LinearLayout.LayoutParams(0, WRAP, 1f));
        root.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));

        listView = new ListView(this);
        listView.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, labels));
        listView.setOnItemClickListener((parent, view, pos, id) -> {
            final String pkg = pkgs.get(pos);
            if (spaceId < 0) {
                toast("Create the space first");
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle(labels.get(pos).split("\n")[0])
                    .setItems(new String[]{"Clone into space", "Launch in space"},
                            (d, which) -> {
                                if (which == 0) {
                                    cloneApp(pkg);
                                } else {
                                    launchApp(pkg);
                                }
                            })
                    .show();
        });
        root.addView(listView, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        logScroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextSize(11);
        logView.setTypeface(Typeface.MONOSPACE);
        logScroll.addView(logView);
        root.addView(logScroll, new LinearLayout.LayoutParams(MATCH, dp(160)));

        setContentView(root);
        enableButtons(false);
    }

    private Button makeButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void appendLog(String s) {
        logView.append(s + "\n\n");
        CharSequence t = logView.getText();
        if (t.length() > 6000) {
            logView.setText(t.subSequence(t.length() - 4000, t.length()));
        }
        logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void enableButtons(boolean ready) {
        createBtn.setEnabled(ready && spaceId < 0);
        removeBtn.setEnabled(ready && spaceId >= 0);
        listView.setEnabled(ready);
    }

    // ---------- App list ----------

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(i, 0);
        List<String[]> tmp = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : found) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) {
                continue;
            }
            tmp.add(new String[]{ri.loadLabel(pm).toString(), pkg});
        }
        Collections.sort(tmp, (a, b) -> a[0].compareToIgnoreCase(b[0]));
        for (String[] t : tmp) {
            labels.add(t[0] + "\n" + t[1]);
            pkgs.add(t[1]);
        }
    }

    // ---------- Shizuku state ----------

    private void refresh() {
        if (!Shizuku.pingBinder()) {
            statusView.setText("Shizuku is not running. Open the Shizuku app and start it.");
            enableButtons(false);
            return;
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                statusView.setText("Permission denied. In the Shizuku app, allow Clone Lite.");
            } else if (!permAsked) {
                permAsked = true;
                Shizuku.requestPermission(REQ_SHIZUKU);
                statusView.setText("Waiting for Shizuku permission...");
            }
            enableButtons(false);
            return;
        }
        if (svc == null) {
            statusView.setText("Connecting to Shizuku...");
            if (!binding) {
                binding = true;
                Shizuku.bindUserService(serviceArgs, conn);
            }
            enableButtons(false);
            return;
        }
        statusView.setText(spaceId >= 0
                ? "Ready. Clone space id: " + spaceId
                : "Ready. No clone space yet.");
        enableButtons(true);
    }

    // ---------- Shell helper ----------

    private void run(String cmd, Consumer<String> cb) {
        io.execute(() -> {
            String out;
            try {
                out = svc.exec(cmd);
            } catch (Exception e) {
                out = "ERROR: " + e;
            }
            final String res = out;
            ui.post(() -> {
                appendLog("$ " + cmd + "\n" + res);
                if (cb != null) {
                    cb.accept(res);
                }
            });
        });
    }

    // ---------- Clone space actions ----------

    private void createSpace() {
        run("pm create-user --profileOf 0 --managed " + SPACE_NAME, r -> findSpace());
    }

    private void findSpace() {
        run("pm list users", r -> {
            Matcher m = Pattern.compile("UserInfo\\{(\\d+):" + SPACE_NAME + ":").matcher(r);
            int id = -1;
            while (m.find()) {
                id = Integer.parseInt(m.group(1));
            }
            spaceId = id;
            refresh();
            if (id >= 0) {
                run("am start-user " + id, null);
            }
        });
    }

    private void confirmRemove() {
        new AlertDialog.Builder(this)
                .setTitle("Remove clone space?")
                .setMessage("This deletes every cloned app and its data.")
                .setPositiveButton("Remove", (d, w) ->
                        run("pm remove-user " + spaceId, r -> {
                            spaceId = -1;
                            refresh();
                        }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void cloneApp(String pkg) {
        if (!pkg.matches("[A-Za-z0-9._]+")) {
            return;
        }
        run("pm install-existing --user " + spaceId + " " + pkg, null);
    }

    private void launchApp(String pkg) {
        if (!pkg.matches("[A-Za-z0-9._]+")) {
            return;
        }
        String cmd = "am start-user " + spaceId + " >/dev/null 2>&1; "
                + "C=$(cmd package resolve-activity --brief --user " + spaceId
                + " -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p "
                + pkg + " | tail -n 1); "
                + "am start --user " + spaceId + " -n \"$C\"";
        run(cmd, null);
    }
}
