package com.example.clonelite;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ_SHIZUKU = 1001;
    private static final String SPACE_NAME = "CloneSpace";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int TICK_MS = 15000;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private Shell shell;
    private SharedPreferences prefs;

    private final List<String> names = new ArrayList<>();
    private final List<String> pkgs = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private final List<SessionCard> sessions = new ArrayList<>();

    private TextView statusView;
    private TextView logView;
    private ScrollView logScroll;
    private Button createBtn;
    private Button removeBtn;
    private Button cleanBtn;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private LinearLayout sessionList;
    private CheckBox autoCache;
    private EditText cacheMinutes;
    private final View[] panes = new View[4];
    private final Button[] tabBtns = new Button[4];

    private Shizuku.UserServiceArgs serviceArgs;
    private IUserService svc;
    private boolean binding = false;
    private boolean permAsked = false;
    private int spaceId = -1;
    private int cacheElapsed = 0;

    private final Shizuku.OnBinderReceivedListener binderReceived =
            () -> ui.post(this::refresh);

    private final Shizuku.OnBinderDeadListener binderDead = () -> {
        svc = null;
        binding = false;
        shell.setService(null);
        ui.post(this::refresh);
    };

    private final Shizuku.OnRequestPermissionResultListener permResult =
            (code, result) -> {
                permAsked = false;
                ui.post(this::refresh);
            };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            svc = IUserService.Stub.asInterface(binder);
            shell.setService(svc);
            binding = false;
            ui.post(() -> {
                refresh();
                findSpace(false);
                // lets apps open on the virtual preview screens
                shell.run("settings put global force_resizable_activities 1", true, null);
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
            shell.setService(null);
            binding = false;
            ui.post(() -> refresh());
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (shell.ready() && spaceId >= 0) {
                for (SessionCard s : new ArrayList<>(sessions)) {
                    s.checkAlive();
                }
                if (autoCache.isChecked()) {
                    cacheElapsed += TICK_MS / 1000;
                    if (cacheElapsed >= cacheMinutesValue() * 60) {
                        cacheElapsed = 0;
                        clearCache();
                    }
                }
            }
            ui.postDelayed(this, TICK_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("clone", MODE_PRIVATE);
        shell = new Shell(ui, this::appendLog);
        loadApps();
        buildUi();
        refreshLabels();

        serviceArgs = new Shizuku.UserServiceArgs(
                new ComponentName(getPackageName(), UserService.class.getName()))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(false)
                .version(1);

        Shizuku.addBinderReceivedListenerSticky(binderReceived);
        Shizuku.addBinderDeadListener(binderDead);
        Shizuku.addRequestPermissionResultListener(permResult);
        refresh();
        ui.postDelayed(tick, TICK_MS);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (serviceArgs != null) {
            refresh();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacks(tick);
        for (SessionCard s : sessions) {
            s.release();
        }
        Shizuku.removeBinderReceivedListener(binderReceived);
        Shizuku.removeBinderDeadListener(binderDead);
        Shizuku.removeRequestPermissionResultListener(permResult);
        try {
            Shizuku.unbindUserService(serviceArgs, conn, false);
        } catch (Throwable ignored) {
        }
        shell.shutdown();
    }

    // ---------- UI ----------

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(10);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Clone Lite");
        title.setTextSize(22);
        root.addView(title, new LinearLayout.LayoutParams(MATCH, WRAP));

        statusView = new TextView(this);
        statusView.setPadding(0, dp(4), 0, dp(6));
        root.addView(statusView, new LinearLayout.LayoutParams(MATCH, WRAP));

        FrameLayout content = new FrameLayout(this);
        panes[0] = buildAppsPane();
        panes[1] = buildSessionsPane();
        panes[2] = buildLogPane();
        panes[3] = buildSettingsPane();
        for (View v : panes) {
            content.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        }
        root.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        String[] tabNames = {"Apps", "Sessions", "Logs", "Settings"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            tabBtns[i] = makeButton(tabNames[i], v -> showTab(idx));
            bar.addView(tabBtns[i], new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        root.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));

        setContentView(root);
        showTab(0);
        enableButtons(false);
    }

    private View buildAppsPane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        createBtn = makeButton("Create space", v -> createSpace());
        removeBtn = makeButton("Remove", v -> confirmRemove());
        cleanBtn = makeButton("Clean", v -> cleanSpace());
        row.addView(createBtn, new LinearLayout.LayoutParams(0, WRAP, 1.3f));
        row.addView(removeBtn, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(cleanBtn, new LinearLayout.LayoutParams(0, WRAP, 1f));
        pane.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));

        listView = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, pos, id) -> {
            final String pkg = pkgs.get(pos);
            final String name = names.get(pos);
            if (spaceId < 0) {
                toast("Create the space first");
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle(name)
                    .setItems(new String[]{"Clone into space", "Add as session"},
                            (d, which) -> {
                                if (which == 0) {
                                    cloneApp(pkg, null);
                                } else {
                                    addSession(pkg, name);
                                }
                            })
                    .show();
        });
        pane.addView(listView, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        return pane;
    }

    private View buildSessionsPane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(makeButton("Start all", v -> startAll()),
                new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(makeButton("Stop all", v -> stopAll()),
                new LinearLayout.LayoutParams(0, WRAP, 1f));
        pane.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));

        ScrollView sv = new ScrollView(this);
        sessionList = new LinearLayout(this);
        sessionList.setOrientation(LinearLayout.VERTICAL);
        sv.addView(sessionList, new ViewGroup.LayoutParams(MATCH, WRAP));
        pane.addView(sv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        return pane;
    }

    private View buildLogPane() {
        logScroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextSize(11);
        logView.setTypeface(Typeface.MONOSPACE);
        logScroll.addView(logView);
        return logScroll;
    }

    private View buildSettingsPane() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(0, dp(8), 0, 0);

        autoCache = new CheckBox(this);
        autoCache.setText("Auto clear cache (does not close running apps)");
        autoCache.setChecked(prefs.getBoolean("auto_cache", false));
        autoCache.setOnCheckedChangeListener((b, on) ->
                prefs.edit().putBoolean("auto_cache", on).apply());
        pane.addView(autoCache);

        TextView lbl = new TextView(this);
        lbl.setText("Every how many minutes:");
        pane.addView(lbl);

        cacheMinutes = new EditText(this);
        cacheMinutes.setSingleLine(true);
        cacheMinutes.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        cacheMinutes.setText(String.valueOf(prefs.getInt("cache_min", 30)));
        pane.addView(cacheMinutes, new LinearLayout.LayoutParams(dp(120), WRAP));

        pane.addView(makeButton("Clear cache now", v -> clearCache()),
                new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView note = new TextView(this);
        note.setPadding(0, dp(12), 0, 0);
        note.setTextSize(12);
        note.setText("Cache clearing uses the system trim command. It frees cache files for "
                + "all apps on the phone, but it does not close anything that is running.\n\n"
                + "Keep this app open while sessions run. The screen is kept awake.");
        pane.addView(note);
        return pane;
    }

    private void showTab(int idx) {
        for (int i = 0; i < 4; i++) {
            panes[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            tabBtns[i].setEnabled(i != idx);
        }
    }

    private Button makeButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void appendLog(String s) {
        logView.append(s + "\n\n");
        CharSequence t = logView.getText();
        if (t.length() > 8000) {
            logView.setText(t.subSequence(t.length() - 5000, t.length()));
        }
        logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void enableButtons(boolean ready) {
        createBtn.setEnabled(ready && spaceId < 0);
        removeBtn.setEnabled(ready && spaceId >= 0);
        cleanBtn.setEnabled(ready && spaceId >= 0);
        listView.setEnabled(ready);
    }

    private int cacheMinutesValue() {
        int m = 30;
        try {
            m = Integer.parseInt(cacheMinutes.getText().toString().trim());
        } catch (Exception ignored) {
        }
        m = Math.max(5, m);
        prefs.edit().putInt("cache_min", m).apply();
        return m;
    }

    // ---------- App list ----------

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(i, 0);
        List<String[]> tmp = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : found) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) {
                continue;
            }
            tmp.add(new String[]{ri.loadLabel(pm).toString(), pkg});
        }
        Collections.sort(tmp, (a, b) -> a[0].compareToIgnoreCase(b[0]));
        for (String[] t : tmp) {
            names.add(t[0]);
            pkgs.add(t[1]);
        }
    }

    private Set<String> cloned() {
        return new HashSet<>(prefs.getStringSet("cloned", new HashSet<>()));
    }

    private void refreshLabels() {
        Set<String> c = cloned();
        labels.clear();
        for (int i = 0; i < pkgs.size(); i++) {
            labels.add((c.contains(pkgs.get(i)) ? "\u2713 " : "") + names.get(i)
                    + "\n" + pkgs.get(i));
        }
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    // ---------- Shizuku state ----------

    private void refresh() {
        if (!Shizuku.pingBinder()) {
            statusView.setText("Shizuku is not running. Open the Shizuku app and start it.");
            enableButtons(false);
            return;
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                statusView.setText("Permission denied. In the Shizuku app, allow Clone Lite.");
            } else if (!permAsked) {
                permAsked = true;
                Shizuku.requestPermission(REQ_SHIZUKU);
                statusView.setText("Waiting for Shizuku permission...");
            }
            enableButtons(false);
            return;
        }
        if (svc == null) {
            statusView.setText("Connecting to Shizuku...");
            if (!binding) {
                binding = true;
                Shizuku.bindUserService(serviceArgs, conn);
            }
            enableButtons(false);
            return;
        }
        statusView.setText(spaceId >= 0
                ? "Ready. Clone space id: " + spaceId
                : "Ready. No clone space yet.");
        enableButtons(true);
    }

    // ---------- Clone space ----------

    private void createSpace() {
        shell.run("pm create-user --profileOf 0 --managed " + SPACE_NAME, false,
                r -> findSpace(true));
    }

    private void findSpace(boolean justCreated) {
        shell.run("pm list users", !justCreated, r -> {
            Matcher m = Pattern.compile("UserInfo\\{(\\d+):" + SPACE_NAME + ":").matcher(r);
            int id = -1;
            while (m.find()) {
                id = Integer.parseInt(m.group(1));
            }
            spaceId = id;
            refresh();
            if (id >= 0) {
                shell.run("am start-user " + id, true, null);
                if (justCreated) {
                    cleanSpace();
                }
            } else if (justCreated) {
                toast("Could not create the space. See Logs.");
            }
        });
    }

    /** Removes every launcher app from the space except the ones you cloned. */
    private void cleanSpace() {
        if (spaceId < 0) {
            return;
        }
        StringBuilder keep = new StringBuilder(" ");
        for (String p : cloned()) {
            keep.append(p).append(" ");
        }
        String cmd = "for p in $(cmd package query-activities --brief --user " + spaceId
                + " -a android.intent.action.MAIN -c android.intent.category.LAUNCHER"
                + " | grep '/' | tr -d ' ' | cut -d/ -f1 | sort -u); do "
                + "case \"" + keep + "\" in *\" $p \"*) continue;; esac; "
                + "case $p in android|com.android.systemui|com.example.clonelite"
                + "|moe.shizuku.privileged.api|com.google.android.webview) continue;; esac; "
                + "pm uninstall --user " + spaceId + " $p >/dev/null 2>&1 "
                + "|| pm disable-user --user " + spaceId + " $p >/dev/null 2>&1; "
                + "echo removed: $p; done";
        shell.run(cmd, false, r -> toast("Space cleaned"));
    }

    private void confirmRemove() {
        new AlertDialog.Builder(this)
                .setTitle("Remove clone space?")
                .setMessage("This deletes every cloned app and its data.")
                .setPositiveButton("Remove", (d, w) -> {
                    stopAll();
                    for (SessionCard s : sessions) {
                        s.release();
                        sessionList.removeView(s);
                    }
                    sessions.clear();
                    shell.run("pm remove-user " + spaceId, false, r -> {
                        spaceId = -1;
                        prefs.edit().remove("cloned").apply();
                        refreshLabels();
                        refresh();
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void cloneApp(String pkg, Runnable then) {
        if (!pkg.matches("[A-Za-z0-9._]+")) {
            return;
        }
        shell.run("pm install-existing --user " + spaceId + " " + pkg, false, r -> {
            if (r.toLowerCase().contains("installed for user")) {
                Set<String> c = cloned();
                c.add(pkg);
                prefs.edit().putStringSet("cloned", c).apply();
                refreshLabels();
                if (then != null) {
                    then.run();
                }
            } else {
                toast("Clone failed. See Logs.");
            }
        });
    }

    // ---------- Sessions ----------

    private void addSession(String pkg, String name) {
        for (SessionCard s : sessions) {
            if (s.pkg.equals(pkg)) {
                toast("Already added");
                showTab(1);
                return;
            }
        }
        Runnable add = () -> {
            SessionCard card = new SessionCard(this, shell, prefs, pkg, name, spaceId);
            sessions.add(card);
            sessionList.addView(card);
            showTab(1);
        };
        if (cloned().contains(pkg)) {
            add.run();
        } else {
            cloneApp(pkg, add);
        }
    }

    private void startAll() {
        int i = 0;
        for (SessionCard s : sessions) {
            final SessionCard sc = s;
            ui.postDelayed(sc::start, i * 10000L);
            i++;
        }
    }

    private void stopAll() {
        for (SessionCard s : sessions) {
            s.stop();
        }
    }

    // ---------- Cache ----------

    private void clearCache() {
        shell.run("cmd package trim-caches 999G", false, r -> toast("Cache cleared"));
    }
}
